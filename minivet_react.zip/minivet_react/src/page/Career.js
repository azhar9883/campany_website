import React, { useState, useRef, useEffect, useCallback } from "react";
import ArrowRightAltIcon from "@mui/icons-material/ArrowRightAlt";
import { FaCircleNotch } from "react-icons/fa";
import VerticalTabs from "../components/tab/VerticalTabs";
import Accordion from "../components/accordion/Accordion";
import data from "../data";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import Header from "../components/header/Header";
import FooterTwo from "../components/footerTwo/FooterTwo";

function Career() {
  const pageName = "career"

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [option, setOption] = useState("");
  const [message, setMessage] = useState("");
  const [selectOption, setSelectOption] = useState("Select");

  const fileInputRef = useRef(null);

  let formData = new FormData();
  formData.append("name", name);
  formData.append("email", email);
  formData.append("message", message);
  formData.append("position", selectOption);
  formData.append("type", pageName)
 
  const onFileUpload = (e) => {
    console.log(e.target.files[0]);
    if (e.target && e.target.files[0]) {
      formData.append("document", e.target.files[0]);
    }
  };

  const handleSubmit = (e) => {
    const id = toast.loading("Please wait...")
    e.preventDefault();
    axios
      .post(
        "https://www.minivetsystem.com/madmin/api/career-mail",
        formData
      )
      .then((res) => {
        toast.dismiss(id);
        if (res.data.status === true) {
          toast.success(res.data.message, {
            position: toast.POSITION.TOP_RIGHT,
          });
        } else if (res.data.status === false) {
          if (res.data.errors.position) {
            toast.error(res.data.errors.position[0], {
              position: toast.POSITION.TOP_RIGHT,
            });
          } else if (res.data.errors.email) {
            toast.error(res.data.errors.email[0], {
              position: toast.POSITION.TOP_RIGHT,
            });
          }
        }
    
      })
      .catch((err) => {

        toast.error("Check Your Network", {
          position: toast.POSITION.TOP_RIGHT,
        });
      });

      setName("");
      setEmail("");
      setMessage("");
      setOption("");
      fileInputRef.current.value = null;
  };

  const handleDataFromChild = (data) => {
    setOption(data);
  };

  const handleSelect = useCallback((e) => {
    setSelectOption(e.target.value);
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    setSelectOption(option)
  }, [option])

  return (
    <>
      <Header />

      <section className="main" id="main">
        <div className="cms-block same-gap">
          <div className="container">
            <div className="row">
              <div className="col-md-5">
                <div className="career-text">
                  <h3 className="heading">
                    <span> We are </span> Hiring
                  </h3>
                  <p>
                    At Minivet System, we encourage professionalism mixed with
                    fun and creativity to enhance and elevate an individual's
                    career growth. We enjoy our work and are passionate about
                    it. We initiate our own ideas and we nurture our own dreams.
                    Everyone at Minivet System shares a common vision - of
                    building great web applications for a global spectator that
                    enable users worldwide to live in the Internet.
                  </p>
                  <h3 className="heading">
                    <span>Key to </span> Join Us
                  </h3>
                  <ul>
                    <li>
                      <FaCircleNotch /> Unlimited opportunity of working with
                      different technologies
                    </li>
                    <li>
                      <FaCircleNotch /> Enjoy a culture of openness with strong
                      values
                    </li>
                    <li>
                      <FaCircleNotch /> We encourge to learn and keep yourself
                      upgraded
                    </li>
                    <li>
                      <FaCircleNotch /> Grow in an atmosphere of excellence and
                      team spirit
                    </li>
                    <li>
                      <FaCircleNotch /> Best practices of HR policies
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-md-7">
                <div className="career-bg">
                  <div className="carrer-content">
                    <img src="assets/images/career-bg3.jpg" alt="no img" />
                    <marquee
                      direction="right"
                      scrollamount="2"
                      style={{ display: "none" }}
                    >

                      <strong> Urgent Opening </strong> <br /> Full Stack .Net
                      Developer <br /> & Laravel with Vue Js Developer
                    </marquee>
                    <div className="carrer-bg-inner">
                      <p>
                        <img src="assets/images/quote-icon.png" alt="no img" />
                      </p>
                      <h3>Urgent Opening</h3>
                      <p>Full Stack .Net Developer </p>
                      <span className="big-font"> & </span>
                      <p> Laravel with Vue Js Developer</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="block7 same-gap">
          <div className="container">
            <VerticalTabs sendDataToParent={handleDataFromChild} />

            {/* verticalTabs start  */}

            {/* verticalTabs end */}

            <Accordion sendDataToAco={handleDataFromChild} />
          </div>
        </div>

        <div className="block5" id="sec2">
          <div className="container">
            <div className="row">
              <div className="col-sm-12">
                <div className="form-sec">
                  <div className="pos4 pos4-career">
                    <img src="./assets/images/img7.png" alt="no img" />
                  </div>
                  <h2>Apply For A Job</h2>
                  <form className="form-horizontal" onSubmit={handleSubmit}>
                    <div className="form-group mar15">
                      <div className="col-sm-4">
                        <input
                          type="text"
                          className="form-control"
                          placeholder="Full Name"
                          id="name"
                          name="name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          required
                        />
                      </div>
                      <div className="col-sm-4">
                        <input
                          type="email"
                          className="form-control"
                          placeholder="Email"
                          id="email"
                          name="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                        />
                      </div>
                      <div className="col-sm-4">
                        <select
                          className="form-control"
                          name="option"
                          value={selectOption}
                          onChange={handleSelect}
                          required
                        >
                          {data.map((item, index) => (
                            <option key={item.id} value={item.label}>
                              {item.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="form-group mar15">
                      <div className="col-sm-12">
                        <textarea
                          className="form-control"
                          placeholder="Message"
                          id="message"
                          name="message"
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          required
                        ></textarea>
                      </div>
                    </div>
                    <div className="form-group mar15">
                      <div className="col-sm-12">
                        <label>Upload your CV</label>
                        <input
                          type="file"
                          name="document"
                          onChange={onFileUpload}
                          ref={fileInputRef}
                          required
                        />
                      </div>
                    </div>
                    {/* <ReCAPTCHA

                      sitekey="6Le0r6UnAAAAAMI-H1R4vDStNZn1vFY2H-K6soyK"
                    /> */}
                    <div className="form-group">
                      <div className="col-sm-12">
                        <button type="submit" className="button2">
                          Submit
                          <span>

                            <ArrowRightAltIcon
                              sx={{ mt: "5px", fontSize: 17 }}
                            />
                          </span>
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <FooterTwo />

      <ToastContainer />
    </>
  );
}

export default Career;
